import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  { q: "Who is eligible to vote?", a: "All active students of Telkom University Surabaya registered in the current academic semester." },
  { q: "How do I log in to the voting portal?", a: "Use your official SSO (Single Sign-On) credentials. The same one used for iGracias." },
  { q: "Is my vote truly anonymous?", a: "Yes. The system uses cryptographic decoupling. Your identity is verified to ensure you haven't voted, but the ballot itself contains no identifying information." },
  { q: "What if I face technical issues during voting?", a: "Contact the IT Helpdesk via the live chat widget on the voting portal or visit the offline help center at the main lobby." },
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-32 px-4 bg-gradient-to-b from-telkom-black to-telkom-maroon">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-16 text-center">Frequently Asked Questions</h2>
        
        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div key={i} className="glass-panel rounded-2xl overflow-hidden border-white/10">
              <button 
                className="w-full px-8 py-6 flex items-center justify-between text-left focus:outline-none"
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
              >
                <span className="text-lg font-bold text-white">{faq.q}</span>
                <ChevronDown className={`w-5 h-5 text-cyan-400 transition-transform duration-300 ${openIndex === i ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence>
                {openIndex === i && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-8 pb-6 text-gray-300 leading-relaxed">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
