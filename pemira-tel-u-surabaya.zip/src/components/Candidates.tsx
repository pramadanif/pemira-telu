import { motion } from 'motion/react';
import { ChevronRight } from 'lucide-react';
import { useState } from 'react';
import { ComparisonModal } from './ComparisonModal';

const candidates = [
  {
    id: 1,
    number: "01",
    pres: "Arjuna W.",
    vp: "Bima S.",
    slogan: "Inovasi Tanpa Batas, Sinergi Tanpa Henti",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=800&h=1000",
  },
  {
    id: 2,
    number: "02",
    pres: "Citra D.",
    vp: "Dimas A.",
    slogan: "Harmoni dalam Keberagaman, Maju Bersama",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800&h=1000",
  }
];

export function Candidates() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <section className="py-32 px-4 bg-telkom-dark relative">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <h2 className="text-5xl md:text-7xl font-display font-bold text-white mb-6 uppercase tracking-tight">The Candidates</h2>
          <p className="text-gray-400 font-mono max-w-2xl mx-auto">Select your future leaders. Hover to reveal their vision.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-24">
          {candidates.map((c, i) => (
            <motion.div 
              key={c.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.2 }}
              className="group relative rounded-[2rem] overflow-hidden aspect-[3/4] bg-telkom-black border border-white/10 shadow-2xl"
            >
              {/* Image */}
              <img 
                src={c.image} 
                alt={`${c.pres} & ${c.vp}`} 
                className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity duration-700 grayscale group-hover:grayscale-0 mix-blend-luminosity group-hover:mix-blend-normal"
                referrerPolicy="no-referrer"
              />
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-telkom-black via-telkom-black/50 to-transparent"></div>

              {/* Number Badge */}
              <div className="absolute top-8 left-8 w-16 h-16 rounded-full glass-panel-light flex items-center justify-center text-2xl font-display font-bold text-white shadow-[0_0_20px_rgba(255,255,255,0.2)]">
                {c.number}
              </div>

              {/* Content */}
              <div className="absolute inset-x-0 bottom-0 p-10 transform translate-y-8 group-hover:translate-y-0 transition-transform duration-500">
                <h3 className="text-4xl font-display font-bold text-white mb-2">{c.pres}</h3>
                <h4 className="text-xl text-gray-300 font-sans mb-6">& {c.vp}</h4>
                
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                  <p className="text-cyan-400 font-serif italic text-xl mb-8 text-glow-cyan">"{c.slogan}"</p>
                  
                  <button 
                    onClick={() => setIsModalOpen(true)}
                    className="flex items-center gap-2 text-sm font-mono uppercase tracking-widest text-white hover:text-cyan-glow transition-colors"
                  >
                    Quick Comparison <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {isModalOpen && <ComparisonModal onClose={() => setIsModalOpen(false)} />}
    </section>
  );
}
